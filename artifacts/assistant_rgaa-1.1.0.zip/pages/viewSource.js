function viewSource(content) {
	document.querySelector('#sources').innerText = content;
}
